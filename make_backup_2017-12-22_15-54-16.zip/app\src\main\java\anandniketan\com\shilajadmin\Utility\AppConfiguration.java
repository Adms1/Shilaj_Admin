package anandniketan.com.shilajadmin.Utility;

/**
 * Created by admsandroid on 11/20/2017.
 */

public class AppConfiguration {

    public static final String BASEURL = "http://192.168.1.5:8085/MobileApp_Service.asmx/";// use for office
//    public static final String BASEURL = "http://103.8.216.132/MobileApp_Service.asmx/"; // use for client



    public static String StudentId;
    public static String TermId;
    public static String TermName;
    public static String TermDetailId;
    public static String TermDetailName;
    public static String ReverseTermDetailId="";
}
