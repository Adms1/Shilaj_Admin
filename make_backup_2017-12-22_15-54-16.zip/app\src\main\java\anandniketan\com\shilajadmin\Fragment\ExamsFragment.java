package anandniketan.com.shilajadmin.Fragment;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import anandniketan.com.shilajadmin.Adapter.ExamListAdapter;
import anandniketan.com.shilajadmin.Adapter.StandardwiseCollectionListAdapter;
import anandniketan.com.shilajadmin.Model.Staff.FinalArrayExamsModel;
import anandniketan.com.shilajadmin.Model.Staff.GetExamsModel;
import anandniketan.com.shilajadmin.R;
import anandniketan.com.shilajadmin.Utility.ApiHandler;
import anandniketan.com.shilajadmin.Utility.Utils;
import anandniketan.com.shilajadmin.databinding.FragmentExamsBinding;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class ExamsFragment extends Fragment implements DatePickerDialog.OnDateSetListener {

    private FragmentExamsBinding fragmentExamsBinding;
    private View rootView;
    private Context mContext;
    private Fragment fragment = null;
    private FragmentManager fragmentManager = null;
    int Year, Month, Day;
    int mYear, mMonth, mDay;
    Calendar calendar;
    String FinalStartDateStr, FinalEndDateStr;
    private static String dateFinal;
    private static boolean isFromDate = false;
    private DatePickerDialog datePickerDialog;
    ExamListAdapter examListAdapter;
    List<FinalArrayExamsModel> finalArrayExamsModel;


    public ExamsFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        fragmentExamsBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_exams, container, false);

        rootView = fragmentExamsBinding.getRoot();
        mContext = getActivity().getApplicationContext();

        setListners();
        callExamsApi();

        return rootView;
    }


    public void setListners() {
        calendar = Calendar.getInstance();
        Year = calendar.get(Calendar.YEAR);
        Month = calendar.get(Calendar.MONTH);
        Day = calendar.get(Calendar.DAY_OF_MONTH);

        fragmentExamsBinding.startDateBtn.setText(Utils.getTodaysDate());
        fragmentExamsBinding.endDateBtn.setText(Utils.getTodaysDate());

        fragmentExamsBinding.btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new StaffFragment();
                fragmentManager = getFragmentManager();
                fragmentManager.beginTransaction()
                        .setCustomAnimations(0, 0)
                        .replace(R.id.frame_container, fragment).commit();
            }
        });
        fragmentExamsBinding.startDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isFromDate = true;
                datePickerDialog = DatePickerDialog.newInstance(ExamsFragment.this, Year, Month, Day);
                datePickerDialog.setThemeDark(false);
                datePickerDialog.setOkText("Done");
                datePickerDialog.showYearPickerFirst(false);
                datePickerDialog.setAccentColor(Color.parseColor("#1B88C8"));
                datePickerDialog.setTitle("Select Date From DatePickerDialog");
                datePickerDialog.show(getActivity().getFragmentManager(), "DatePickerDialog");
            }
        });
        fragmentExamsBinding.endDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isFromDate = false;
                datePickerDialog = DatePickerDialog.newInstance(ExamsFragment.this, Year, Month, Day);
                datePickerDialog.setThemeDark(false);
                datePickerDialog.setOkText("Done");
                datePickerDialog.showYearPickerFirst(false);
                datePickerDialog.setAccentColor(Color.parseColor("#1B88C8"));
                datePickerDialog.setTitle("Select Date From DatePickerDialog");
                datePickerDialog.show(getActivity().getFragmentManager(), "DatePickerDialog");
            }
        });
        fragmentExamsBinding.filterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callExamsApi();
            }
        });
    }

    // CALL Exams API HERE
    private void callExamsApi() {

        if (!Utils.checkNetwork(mContext)) {
            Utils.showCustomDialog(getResources().getString(R.string.internet_error), getResources().getString(R.string.internet_connection_error), getActivity());
            return;
        }

        Utils.showDialog(getActivity());
        ApiHandler.getApiService().getExams(getExamsDetail(), new retrofit.Callback<GetExamsModel>() {
            @Override
            public void success(GetExamsModel examsModel, Response response) {
                Utils.dismissDialog();
                if (examsModel == null) {
                    Utils.ping(mContext, getString(R.string.something_wrong));
                    return;
                }
                if (examsModel.getSuccess() == null) {
                    Utils.ping(mContext, getString(R.string.something_wrong));
                    return;
                }
                if (examsModel.getSuccess().equalsIgnoreCase("false")) {
                    fragmentExamsBinding.txtNoRecords.setVisibility(View.VISIBLE);
                    fragmentExamsBinding.examsHeaderLinear.setVisibility(View.GONE);
                    fragmentExamsBinding.listExamLinear.setVisibility(View.GONE);
//                    Utils.ping(mContext, getString(R.string.false_msg));
                    return;
                }
                if (examsModel.getSuccess().equalsIgnoreCase("True")) {
                    finalArrayExamsModel = examsModel.getFinalArray();
                    if (finalArrayExamsModel != null) {
                        fragmentExamsBinding.txtNoRecords.setVisibility(View.GONE);
                        fragmentExamsBinding.examsHeaderLinear.setVisibility(View.VISIBLE);
                        fragmentExamsBinding.listExamLinear.setVisibility(View.VISIBLE);
                        examListAdapter = new ExamListAdapter(getActivity(), finalArrayExamsModel);
                        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                        fragmentExamsBinding.examList.setLayoutManager(mLayoutManager);
                        fragmentExamsBinding.examList.setItemAnimator(new DefaultItemAnimator());
                        fragmentExamsBinding.examList.setAdapter(examListAdapter);
                    }
                }
            }

            @Override
            public void failure(RetrofitError error) {
                Utils.dismissDialog();
                error.printStackTrace();
                error.getMessage();
                Utils.ping(mContext, getString(R.string.something_wrong));
            }
        });

    }

    private Map<String, String> getExamsDetail() {
        FinalStartDateStr = fragmentExamsBinding.startDateBtn.getText().toString();
        FinalEndDateStr = fragmentExamsBinding.endDateBtn.getText().toString();

        Map<String, String> map = new HashMap<>();
        map.put("Stdt", FinalStartDateStr);
        map.put("EndDt", FinalEndDateStr);
        return map;
    }

    @Override
    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
        populateSetDate(year, monthOfYear + 1, dayOfMonth);
    }

    public void populateSetDate(int year, int month, int day) {
        String d, m, y;
        d = Integer.toString(day);
        m = Integer.toString(month);
        y = Integer.toString(year);
        if (day < 10) {
            d = "0" + d;
        }
        if (month < 10) {
            m = "0" + m;
        }

        dateFinal = d + "/" + m + "/" + y;
        if (isFromDate) {
            fragmentExamsBinding.startDateBtn.setText(dateFinal);
        } else {
            fragmentExamsBinding.endDateBtn.setText(dateFinal);
        }
    }
}

