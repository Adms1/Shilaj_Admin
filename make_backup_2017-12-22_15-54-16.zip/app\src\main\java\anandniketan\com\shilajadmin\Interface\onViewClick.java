package anandniketan.com.shilajadmin.Interface;

/**
 * Created by admsandroid on 11/21/2017.
 */

public interface onViewClick {
    public void getViewClick();
}
