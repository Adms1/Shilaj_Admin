package anandniketan.com.shilajadmin.Interface;

/**
 * Created by admsandroid on 12/21/2017.
 */

public interface getEmployeeCheck {
    public void getEmployeeSMSCheck();
}
